# Lecteurs C++ des fichiers .bin d'Acoustimeter

Deux programmes, comme en MATLAB et en Python :

| Programme | Pour quels .bin |
|---|---|
| `acoustimeter_mesure` | fenêtre Mesure (ACMB) |
| `acoustimeter_enregistrement` | Supervision et SAVE MLI (ACOUSBIN) |

Un fichier donné au mauvais programme est ouvert correctement quand même.

## Compiler (Windows, même Qt qu'Acoustimeter)

Dans l'« Invite de commandes x64 Native Tools for VS 2022 », depuis ce dossier :

```bat
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH=D:/maxime/C/Qt/6.12.0/msvc2022_64
cmake --build build
D:\maxime\C\Qt\6.12.0\msvc2022_64\bin\windeployqt build\acoustimeter_mesure.exe build\acoustimeter_enregistrement.exe
```

`windeployqt` copie les DLL Qt à côté des .exe : ils peuvent alors être lancés sur un autre PC.
Seul Qt 6 Widgets est nécessaire (pas Qt Charts, pas NI).

## Utiliser

```bat
acoustimeter_mesure                                   :: fenêtre pour choisir le fichier
acoustimeter_mesure mesure.bin                        :: résumé + courbes
acoustimeter_mesure mesure.bin --y G_S B_S --export csv
acoustimeter_enregistrement enr.bin --voies Hydro --debut 10 --fin 10.05 --export csv wav
acoustimeter_enregistrement trames_MLI.bin --pont MLI1 MLI3 --export wav
acoustimeter_enregistrement --help
```

Dans la fenêtre de courbes : molette = zoom, glisser = déplacer, double-clic = vue complète ;
les coordonnées sous la souris s'affichent en bas. Les panneaux d'un enregistrement zooment ensemble.

`--png fichier.png --pas-de-trace` produit l'image sans ouvrir de fenêtre (traitement par lots).

## Utiliser la lecture dans votre propre code

`fichiers_acoustimeter.h/.cpp` ne dépend que de Qt Core :

```cpp
#include "fichiers_acoustimeter.h"
acous::Mesure m; QString err;
if (acous::lireMesure("mesure.bin", m, err)) {
    const auto f = m.colonne("f_Hz"), tvr = m.colonne("TVR");     // NaN = non mesuré
}
acous::Enregistrement r;
if (acous::lireEnregistrement("enr.bin", r, err)) {
    const acous::Voie& h = r.voies[r.indice("Hydro 1")];
    for (size_t i = 0; i < h.taille(); ++i) { double t = h.temps(i), v = h.v(i); }
}
```

## Différences avec MATLAB / Python

- Export CSV et WAV seulement (pas de .mat).
- Pas d'écoute directe : exporter en WAV puis l'ouvrir.
